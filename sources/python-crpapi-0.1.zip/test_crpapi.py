import doctest

print 'Before testing be sure to set your key in README.txt..\n\n'

doctest.testfile('README.rst')
