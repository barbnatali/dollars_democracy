CYCLES = ['06',"08", "10","12"]

CRP_EMAIL = #Your MyOpenSecrets login
CRP_PASSWORD = ''
MYSQL_HOST = "localhost" 
MYSQL_USER = "root" #Your MySQL login
MYSQL_PASSWORD = ""
MYSQL_DB = "crp" #create this database manually before running

SRC_PATH = 'download'
DEST_PATH = 'raw'
